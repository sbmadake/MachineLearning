# ml-model-deployment-aws-ec2
codes related to aws ec2 deployment
